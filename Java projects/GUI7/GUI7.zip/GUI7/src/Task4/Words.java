package Task4;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Words implements Iterable<Map.Entry<String,Integer>>, Iterator<Map.Entry<String,Integer>>
{
    private String file;
    public Words(String file)
    {
        this.file = file;
    }

    @Override
    public Iterator<Map.Entry<String, Integer>> iterator()
    {
        return this;
    }

    @Override
    public boolean hasNext()
    {
        return true;
    }



    /// Göteborg -> 2
    // Kitty -> 3
    // Łódź -> 3
    // Paul -> 3
    @Override
    public Map.Entry<String, Integer> next()
    {
        Map<Object,Long> lines = null;
        List<String> strings;
        List<Integer> counts;
        try(Stream<String> line = Files.lines(Paths.get(file)))
        {
            System.out.println();
            strings = line.flatMap(words -> Arrays.stream(words.split("\\s+")))
                    .filter(word->
                    {
                        char[] arr = word.toCharArray();
                        
                        return Character.isLetter()
                    })
                    .map(word -> word.substring(0,1).toUpperCase() + word.substring(1).toLowerCase())
                    .toList();
            lines = strings.stream().collect(Collectors.groupingBy(word -> word, Collectors.counting()));
            System.out.println(lines);
            System.out.println(strings);
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }

        return null;
    }
}
